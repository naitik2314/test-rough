#!/usr/bin/env python3
import os, sys, pathlib, requests

"""Fetches Michigan county GeoJSON (cartographic boundaries, lightweight).
Writes to data/mi_counties.geojson (default) or a path you pass)."""

def main():
    out = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path("data/mi_counties.geojson")
    out.parent.mkdir(parents=True, exist_ok=True)
    url = "https://www2.census.gov/geo/tiger/GENZ2018/shp/cb_2018_26_county_500k.json"
    r = requests.get(url, timeout=60)
    r.raise_for_status()
    out.write_bytes(r.content)
    print(f"Wrote {out} ({len(r.content)} bytes)")

if __name__ == "__main__":
    main()
