# Health Intelligence Engine — **GKG Prefilter** (Wayne/Oakland)

This version **does not** enumerate Mentions. It uses **GDELT GKG 2.0** files
(`*.gkg.csv.zip` + `*.translation.gkg.csv.zip`) to prefilter to **Michigan**
and specifically **Wayne/Oakland** via the `V2Locations` field (per GDELT docs).
Only those document URLs are then crawled and LLM-processed.

Why it's fast: you avoid crawling the world and only fetch MI-relevant URLs.

### Windows 11 setup (64 GB RAM)
1. Install Python 3.11+, PostgreSQL 16+; create DB `health_intel`.
2. Install Ollama → `ollama pull llama3.1:8b-instruct`
3. Install uv → `powershell -ExecutionPolicy Bypass -c "irm https://astral.sh/uv/install.ps1 | iex"`
4. In project folder:
   ```powershell
   copy .env.sample .env
   # set DATABASE_URL
   uv sync
   uv run python -m spacy download en_core_web_sm
   ```
5. (Optional) `uv run python utils/get_census_geojson.py`
6. Run:
   ```powershell
   uv run pipeline.py run --start 2025-08-20 --end 2025-08-21
   ```
7. One-year backfill:
   ```powershell
   uv run pipeline.py run --start 2024-08-25 --end 2025-08-25
   ```

### Notes
- We prefer **V2Locations** (semicolon-separated locations; each location is `#`-delimited)
  in the order: **Type, FullName, CountryCode, ADM1Code, ADM2Code, Lat, Long, FeatureID, CharOffset**.
- US+MI filter uses `CountryCode=='US'` and `ADM1Code` ending `MI` or `FullName` includes 'Michigan'.
- Wayne/Oakland narrowing uses (a) lat/lon point-in-polygon when available and (b) county/city names.
- After crawl, we still persist locations (county) + open-set health extraction JSON.

