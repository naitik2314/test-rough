#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GDELT GKG-prefilter (Michigan -> Wayne/Oakland) -> Crawl -> Local LLM Open-set Extraction -> Aggregates
"""
from __future__ import annotations

import os, re, io, sys, csv, json, argparse, asyncio, hashlib, zipfile
from datetime import datetime, timedelta, timezone
from typing import Optional, List, Dict, Set, Tuple

import httpx
from tqdm import tqdm
import ujson
from dotenv import load_dotenv
import psycopg
from psycopg.rows import dict_row
from pydantic import BaseModel, Field

import trafilatura
from bs4 import BeautifulSoup

try:
    import spacy
except Exception:
    spacy = None

from shapely.geometry import shape, Point
import ollama

# Scope
WAYNE_FIPS = "26163"
OAKLAND_FIPS = "26125"
METRO_DETROIT_COUNTIES = [WAYNE_FIPS, OAKLAND_FIPS]

# GDELT master lists
MASTERFILELIST_URLS = [
    "http://data.gdeltproject.org/gdeltv2/masterfilelist.txt",
    "http://data.gdeltproject.org/gdeltv2/masterfilelist-translation.txt",
]
GKG_URL_RE = re.compile(
    r'(?P<url>(?:https?://)?(?:data\.gdeltproject\.org/)?gdeltv2/(?P<ts>\d{14})(?:\.translation)?\.gkg\.csv\.zip)',
    re.I
)

# Paywalls
HARD_PAYWALL_DOMAINS = {"wsj.com","ft.com","bloomberg.com","nytimes.com","theathletic.com","economist.com","financialpost.com","foreignpolicy.com"}

DET_COUNTY_RE = re.compile(r'\b(wayne|oakland)\s+county\b', re.I)
METRO_RE      = re.compile(r'\bmetro\s+detroit\b', re.I)
LATLON_RE     = re.compile(r'([-+]?\d{1,2}\.\d+)[,\s]+([-+]?\d{1,3}\.\d+)')

with open("data/wayne_oakland_cities.json","r",encoding="utf-8") as f:
    _CITY_MAP = json.load(f)
WAYNE_CITIES   = set(map(str.lower, _CITY_MAP["wayne"]))
OAKLAND_CITIES = set(map(str.lower, _CITY_MAP["oakland"]))

try:
    _NLP = spacy.load("en_core_web_sm") if spacy is not None else None
except Exception:
    _NLP = None

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS articles (
    id BIGSERIAL PRIMARY KEY,
    url TEXT NOT NULL,
    url_hash TEXT NOT NULL UNIQUE,
    source_time TIMESTAMP NULL,
    outlet TEXT NULL,
    title TEXT NULL,
    pubdate TIMESTAMP NULL,
    html_sha TEXT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS article_text (
    article_id BIGINT PRIMARY KEY REFERENCES articles(id) ON DELETE CASCADE,
    text TEXT,
    html TEXT,
    fetch_status INTEGER,
    content_bytes INTEGER,
    extracted_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS article_health (
    article_id BIGINT PRIMARY KEY REFERENCES articles(id) ON DELETE CASCADE,
    is_health BOOLEAN NOT NULL,
    health_conf NUMERIC,
    gating_path TEXT,
    model_versions JSONB,
    decided_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- RAW disease surfaces (open-set) if available
CREATE TABLE IF NOT EXISTS article_diseases (
    id BIGSERIAL PRIMARY KEY,
    article_id BIGINT REFERENCES articles(id) ON DELETE CASCADE,
    code_system TEXT DEFAULT 'raw',
    code TEXT NULL,
    label TEXT NOT NULL,
    confidence NUMERIC,
    offsets JSONB NULL
);
CREATE INDEX IF NOT EXISTS idx_article_diseases_article ON article_diseases(article_id);

CREATE TABLE IF NOT EXISTS article_locations (
    id BIGSERIAL PRIMARY KEY,
    article_id BIGINT REFERENCES articles(id) ON DELETE CASCADE,
    geoid TEXT NOT NULL,
    geotype TEXT NOT NULL,
    name TEXT NULL,
    confidence NUMERIC,
    method TEXT,
    geo_precision TEXT NOT NULL,
    UNIQUE(article_id, geoid, geotype)
);

CREATE TABLE IF NOT EXISTS aggregates_weekly (
    week_start DATE NOT NULL,
    county_fips TEXT NOT NULL,
    disease_label TEXT NOT NULL,
    article_count INTEGER NOT NULL,
    PRIMARY KEY (week_start, county_fips, disease_label)
);

CREATE TABLE IF NOT EXISTS article_health_open (
    article_id BIGINT PRIMARY KEY REFERENCES articles(id) ON DELETE CASCADE,
    extraction JSONB NOT NULL,
    model_versions JSONB,
    decided_at TIMESTAMP NOT NULL DEFAULT NOW()
);
"""

def url_hash(url: str) -> str:
    return hashlib.sha1(url.encode("utf-8")).hexdigest()

def canonicalize_url(url: str) -> str:
    from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
    try:
        parts = urlsplit(url.strip())
    except Exception:
        return url.strip()
    q = [(k,v) for (k,v) in parse_qsl(parts.query, keep_blank_values=True)
         if not k.lower().startswith(("utm_","fbclid","gclid","mc_cid","mc_eid"))]
    new_query = urlencode(sorted(q))
    return urlunsplit((parts.scheme, parts.netloc.lower(), parts.path, new_query, ""))

def is_hard_paywall(url: str) -> bool:
    from urllib.parse import urlsplit
    host = urlsplit(url).netloc.lower()
    return any(host.endswith(d) for d in HARD_PAYWALL_DOMAINS)

# ---------- GKG Discovery + Michigan prefilter ----------
async def list_gkg_files_from_masterlists(client: httpx.AsyncClient, start: datetime, end: datetime) -> List[str]:
    urls: Set[str] = set()
    for src in MASTERFILELIST_URLS:
        r = await client.get(src, timeout=300)
        r.raise_for_status()
        for m in GKG_URL_RE.finditer(r.text):
            ts = m.group("ts")
            try:
                dt = datetime.strptime(ts, "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
            except Exception:
                continue
            if start <= dt <= end:
                url = m.group("url")
                if not url.startswith("http"):
                    url = "http://data.gdeltproject.org/" + url.lstrip("/")
                urls.add(url)
    return sorted(urls)

def _parse_v2locations(loc_field: str) -> List[dict]:
    out = []
    if not loc_field:
        return out
    for token in loc_field.split(";"):
        token = token.strip()
        if not token:
            continue
        parts = token.split("#")
        if len(parts) < 4:
            continue
        try:
            loc_type = int(parts[0])
        except Exception:
            loc_type = None
        fullname = parts[1]
        ccode    = parts[2] if len(parts) > 2 else None
        adm1     = parts[3] if len(parts) > 3 else None
        adm2     = parts[4] if len(parts) > 4 else None
        lat      = float(parts[5]) if len(parts) > 5 and parts[5] else None
        lon      = float(parts[6]) if len(parts) > 6 and parts[6] else None
        out.append({
            "type": loc_type,
            "fullname": fullname,
            "country": ccode,
            "adm1": adm1,
            "adm2": adm2,
            "lat": lat,
            "lon": lon
        })
    return out

def _fullname_city(fullname: str) -> str:
    if not fullname: return ""
    return fullname.split(",")[0].strip()

def _match_mi_wayne_oakland(loc: dict, polys: Dict[str, Dict]) -> Optional[str]:
    fullname = (loc.get("fullname") or "").lower()
    adm1 = (loc.get("adm1") or "").upper()
    country = (loc.get("country") or "").upper()
    if not (country == "US" and ("USMI" in adm1 or "michigan" in fullname)):
        return None
    lat, lon = loc.get("lat"), loc.get("lon")
    if lat is not None and lon is not None and polys:
        pt = Point(lon, lat)
        for geoid, rec in polys.items():
            if rec["shape"].contains(pt):
                return geoid
    city = _fullname_city(loc.get("fullname","")).lower()
    if "wayne county" in fullname:   return "26163"
    if "oakland county" in fullname: return "26125"
    if city in (c.lower() for c in WAYNE_CITIES):   return "26163"
    if city in (c.lower() for c in OAKLAND_CITIES): return "26125"
    return None

async def collect_urls_via_gkg(start: datetime, end: datetime, polys: Dict[str, Dict]) -> List[str]:
    async with httpx.AsyncClient(follow_redirects=True, timeout=60) as client:
        files = await list_gkg_files_from_masterlists(client, start, end)
        kept_urls: Set[str] = set()
        scanned = 0
        for zurl in tqdm(files, desc="GKG zips (MI prefilter)"):
            try:
                r = await client.get(zurl, timeout=300)
                r.raise_for_status()
                z = zipfile.ZipFile(io.BytesIO(r.content))
                for name in z.namelist():
                    with z.open(name) as f:
                        reader = csv.reader(io.TextIOWrapper(f, encoding="utf-8", errors="ignore"), delimiter="\t")
                        for row in reader:
                            scanned += 1
                            doc_url = None
                            if len(row) >= 5 and row[4].startswith(("http://","https://")):
                                doc_url = row[4].strip()
                            loc_field = row[10] if len(row) > 10 else (row[9] if len(row) > 9 else "")
                            if not loc_field:
                                continue
                            for loc in _parse_v2locations(loc_field):
                                geoid = _match_mi_wayne_oakland(loc, polys)
                                if geoid and doc_url:
                                    kept_urls.add(canonicalize_url(doc_url))
                                    break
            except Exception as e:
                print(f"[WARN] Failed {zurl}: {e}")
        print(f"Prefiltered {len(kept_urls)} URLs for MI/Wayne/Oakland from {len(files)} GKG files, {scanned:,} rows scanned.")
        return sorted(kept_urls)

# ---------- Crawl & extract ----------
class Fetched(BaseModel):
    url: str
    status: int
    html: Optional[str] = None
    text: Optional[str] = None
    title: Optional[str] = None
    html_sha: Optional[str] = None

def safe_extract(html: str) -> Tuple[Optional[str], Optional[str]]:
    try:
        txt = trafilatura.extract(html, include_comments=False, include_tables=False, favor_recall=True)
        if not txt:
            soup = BeautifulSoup(html, "lxml")
            txt = soup.get_text(separator=" ", strip=True)
        soup = BeautifulSoup(html, "lxml")
        title = soup.title.string.strip() if (soup.title and soup.title.string) else None
        return txt, title
    except Exception:
        return None, None

async def fetch_one(client: httpx.AsyncClient, url: str, timeout: int) -> Fetched:
    if is_hard_paywall(url):
        return Fetched(url=url, status=451)
    try:
        r = await client.get(url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome Safari",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        }, timeout=timeout)
        status = r.status_code
        if status >= 400:
            return Fetched(url=url, status=status)
        html = r.text
        txt, title = safe_extract(html)
        sha = hashlib.sha1(r.content).hexdigest()
        return Fetched(url=url, status=status, html=html, text=txt, title=title, html_sha=sha)
    except Exception:
        return Fetched(url=url, status=598)

async def crawl_urls(urls: List[str], concurrency: int, req_timeout: int) -> List[Fetched]:
    sem = asyncio.Semaphore(concurrency)
    results: List[Fetched] = []
    async with httpx.AsyncClient(follow_redirects=True, timeout=req_timeout) as client:
        async def bound(u):
            async with sem:
                results.append(await fetch_one(client, u, req_timeout))
        tasks = [asyncio.create_task(bound(u)) for u in urls]
        for _ in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc="Crawling"):
            await _
    return results

# ---------- Open-set LLM ----------
class OpenEntity(BaseModel):
    type: str
    surface: str
    code_system: Optional[str] = None
    code: Optional[str] = None
    span: Optional[List[int]] = None

class OpenEvent(BaseModel):
    what: Optional[str] = None
    count: Optional[int] = None
    unit: Optional[str] = None
    date: Optional[str] = None
    location_text: Optional[str] = None
    notes: Optional[str] = None

class OpenHealthExtraction(BaseModel):
    is_health: bool
    confidence: float
    entities: List[OpenEntity] = Field(default_factory=list)
    events: List[OpenEvent] = Field(default_factory=list)

def build_open_extract_prompt(title: str, text: str) -> str:
    snippet = ((title or "") + "\n\n" + (text or ""))[:6000]
    return f"""Extract health intelligence as JSON. 
Return keys: is_health (bool), confidence (float 0..1),
entities (array of objects with: type [disease|symptom|agent|exposure|intervention|population|facility], surface),
events (array of objects with: what, count, unit, date, location_text, notes).
STRICT JSON ONLY. No commentary.

TEXT:
\"\"\"{snippet}\"\"\""""

async def llm_open_extract(model: str, title: str, text: str) -> Optional[OpenHealthExtraction]:
    prompt = build_open_extract_prompt(title, text)
    try:
        res = await asyncio.to_thread(ollama.generate, model=model, prompt=prompt, options={"temperature": 0})
        m = re.search(r'\{.*\}', res.get("response",""), re.S)
        if not m: return None
        return OpenHealthExtraction.model_validate_json(m.group(0))
    except Exception:
        return None

# ---------- Geo helpers ----------
def load_mi_county_polygons(geojson_path: str|None) -> Dict[str, Dict]:
    if not geojson_path or not os.path.exists(geojson_path):
        return {}
    with open(geojson_path, "r", encoding="utf-8") as f:
        gj = json.load(f)
    polys = {}
    for feat in gj.get("features", []):
        props = feat.get("properties", {})
        geoid = props.get("GEOID")
        name  = props.get("NAME")
        if geoid in (WAYNE_FIPS, OAKLAND_FIPS):
            polys[geoid] = {"name": name, "shape": shape(feat["geometry"])}
    return polys

def resolve_county_by_rules(title: Optional[str], text: Optional[str]) -> Tuple[Set[str], str, float]:
    s = ((title or "") + " " + (text or "")).lower()
    got: Set[str] = set()
    method = "rules"
    conf = 0.5
    if DET_COUNTY_RE.search(s):
        if "wayne county" in s:   got.add(WAYNE_FIPS);   conf = max(conf, 0.9)
        if "oakland county" in s: got.add(OAKLAND_FIPS); conf = max(conf, 0.9)
    if METRO_RE.search(s):
        got.update(METRO_DETROIT_COUNTIES); conf = max(conf, 0.8)
    if any(f" {c.lower()} " in f" {s} " for c in WAYNE_CITIES):
        got.add(WAYNE_FIPS);   conf = max(conf, 0.7)
    if any(f" {c.lower()} " in f" {s} " for c in OAKLAND_CITIES):
        got.add(OAKLAND_FIPS); conf = max(conf, 0.7)
    return got, method, conf

def restrict_to_scope(fips: Set[str]) -> Set[str]:
    return {f for f in fips if f in (WAYNE_FIPS, OAKLAND_FIPS)}

# ---------- Persistence ----------
class DB:
    def __init__(self, dsn: str):
        self.dsn = dsn
    def connect(self):
        return psycopg.connect(self.dsn, row_factory=dict_row)

def db_init(db: DB):
    with db.connect() as cx:
        cx.execute(SCHEMA_SQL)
        cx.commit()

def upsert_article(cx, url: str, outlet: Optional[str], title: Optional[str], pubdate: Optional[datetime], html_sha: Optional[str]) -> int:
    h = url_hash(url)
    cur = cx.execute("""
        INSERT INTO articles(url, url_hash, outlet, title, pubdate, html_sha)
        VALUES (%s, %s, %s, %s, %s, %s)
        ON CONFLICT (url_hash) DO UPDATE SET
          outlet   = COALESCE(EXCLUDED.outlet,   articles.outlet),
          title    = COALESCE(EXCLUDED.title,    articles.title),
          pubdate  = COALESCE(EXCLUDED.pubdate,  articles.pubdate),
          html_sha = COALESCE(EXCLUDED.html_sha, articles.html_sha)
        RETURNING id;
    """, (url, h, outlet, title, pubdate, html_sha))
    return cur.fetchone()["id"]

def upsert_article_text(cx, article_id: int, text: Optional[str], html: Optional[str], status: int):
    cx.execute("""
        INSERT INTO article_text(article_id, text, html, fetch_status, content_bytes)
        VALUES (%s, %s, %s, %s, %s)
        ON CONFLICT (article_id) DO UPDATE SET
          text          = COALESCE(EXCLUDED.text,  article_text.text),
          html          = COALESCE(EXCLUDED.html,  article_text.html),
          fetch_status  = EXCLUDED.fetch_status,
          content_bytes = EXCLUDED.content_bytes
    """, (article_id, text, html, status, len(html.encode("utf-8")) if html else None))

def upsert_article_health(cx, article_id: int, is_health: bool, conf: float, gating_path: str, model_versions: dict):
    cx.execute("""
        INSERT INTO article_health(article_id, is_health, health_conf, gating_path, model_versions)
        VALUES (%s, %s, %s, %s, %s)
        ON CONFLICT (article_id) DO UPDATE SET
          is_health     = EXCLUDED.is_health,
          health_conf   = EXCLUDED.health_conf,
          gating_path   = EXCLUDED.gating_path,
          model_versions= EXCLUDED.model_versions
    """, (article_id, is_health, conf, gating_path, json.dumps(model_versions)))

def upsert_article_health_open(cx, article_id: int, extraction: dict, model_versions: dict):
    cx.execute("""
      INSERT INTO article_health_open(article_id, extraction, model_versions)
      VALUES (%s, %s, %s)
      ON CONFLICT (article_id) DO UPDATE SET
        extraction = EXCLUDED.extraction,
        model_versions = EXCLUDED.model_versions
    """, (article_id, json.dumps(extraction), json.dumps(model_versions)))

def insert_diseases_from_open(cx, article_id: int, open_entities: List[dict]):
    for ent in open_entities or []:
        if (ent.get("type") or "").lower() == "disease":
            surface = ent.get("surface")
            if not surface: 
                continue
            cx.execute("""
                INSERT INTO article_diseases(article_id, code_system, code, label, confidence, offsets)
                VALUES (%s, 'raw', NULL, %s, %s, %s)
            """, (article_id, surface, 0.9, json.dumps(ent.get("span")) if ent.get("span") else None))

def insert_locations(cx, article_id: int, fips_set: Set[str], method: str, conf: float):
    for f in fips_set:
        name = "Wayne County" if f == WAYNE_FIPS else "Oakland County"
        cx.execute("""
            INSERT INTO article_locations(article_id, geoid, geotype, name, confidence, method, geo_precision)
            VALUES (%s, %s, 'county', %s, %s, %s, 'county')
            ON CONFLICT (article_id, geoid, geotype) DO NOTHING
        """, (article_id, f, name, conf, method))

def recompute_weekly_aggregates(cx, start: datetime, end: datetime):
    cx.execute("DELETE FROM aggregates_weekly WHERE week_start BETWEEN %s AND %s", (start.date(), end.date()))
    cx.execute(f"""
        INSERT INTO aggregates_weekly(week_start, county_fips, disease_label, article_count)
        SELECT
          date_trunc('week', COALESCE(a.pubdate, NOW()))::date AS week_start,
          al.geoid AS county_fips,
          COALESCE(NULLIF(ad.label, ''), 'health') AS disease_label,
          COUNT(DISTINCT a.id) AS article_count
        FROM articles a
        JOIN article_health ah ON ah.article_id = a.id AND ah.is_health = TRUE
        JOIN article_locations al ON al.article_id = a.id AND al.geotype='county' AND al.geoid IN ('{WAYNE_FIPS}','{OAKLAND_FIPS}')
        LEFT JOIN article_diseases ad ON ad.article_id = a.id
        GROUP BY 1,2,3
        ON CONFLICT DO NOTHING;
    """)

# ---------- Orchestration ----------
async def pipeline_run(start: datetime, end: datetime, mi_geojson_path: Optional[str] = None):
    load_dotenv()
    dsn = os.getenv("DATABASE_URL","").strip()
    if not dsn:
        print("DATABASE_URL is required in .env"); sys.exit(2)
    db = DB(dsn)
    with db.connect() as cx:
        db_init(db)

    polys = load_mi_county_polygons(mi_geojson_path or os.getenv("MI_COUNTY_GEOJSON",""))
    urls  = await collect_urls_via_gkg(start, end, polys)

    max_conc = int(os.getenv("MAX_CONCURRENCY","64"))
    req_to   = int(os.getenv("REQUEST_TIMEOUT_SECS","20"))
    fetched  = await crawl_urls(urls, max_conc, req_to)

    model = os.getenv("OLLAMA_MODEL","llama3.1:8b-instruct")

    kept = 0
    with db.connect() as cx:
        for item in tqdm(fetched, desc="Persisting"):
            if item.status not in (200, 204): 
                continue

            aid = upsert_article(cx, item.url, None, item.title, None, item.html_sha)
            upsert_article_text(cx, aid, item.text, item.html, item.status)

            open_out = await llm_open_extract(model, item.title or "", item.text or "")
            if open_out:
                upsert_article_health_open(cx, aid, open_out.model_dump(), {"ollama_model": model})
                is_health = bool(open_out.is_health)
                conf = float(open_out.confidence)
            else:
                is_health = False
                conf = 0.0

            upsert_article_health(cx, aid, is_health, conf, "open_llm" if open_out else "none", {"ollama_model": model})
            if not is_health:
                continue

            fips_set, method, gconf = resolve_county_by_rules(item.title, item.text)
            fips_set = restrict_to_scope(fips_set)
            if not fips_set:
                continue
            insert_locations(cx, aid, fips_set, method, gconf)
            kept += 1

        recompute_weekly_aggregates(cx, start, end)
        cx.commit()
    print(f"Done. Kept {kept} health articles for Wayne/Oakland.")

def parse_args(argv=None):
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    runp = sub.add_parser("run", help="Run end-to-end pipeline (GKG-prefiltered)")
    runp.add_argument("--start", required=True, help="YYYY-MM-DD")
    runp.add_argument("--end", required=True, help="YYYY-MM-DD")
    runp.add_argument("--mi-county-geojson", default=None, help="Optional path to MI county GeoJSON")
    return ap.parse_args(argv)

def cli_main():
    args = parse_args()
    if args.cmd == "run":
        start = datetime.strptime(args.start, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        end   = datetime.strptime(args.end,   "%Y-%m-%d").replace(tzinfo=timezone.utc)
        asyncio.run(pipeline_run(start, end, args.mi_county_geojson))

if __name__ == "__main__":
    cli_main()
